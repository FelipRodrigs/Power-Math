var question1 = document.getElementById("question1");

var question2 = document.getElementById("question2");

var question3 = document.getElementById("question3");

var question4 = document.getElementById("question4");

var question5 = document.getElementById("question5");

var text;

text = document.getElementById("answer1");

var text2;

text2 = document.getElementById("answer2");

var text3;

text3 = document.getElementById("answer3");

var text4;

text4 = document.getElementById("answer4");

var text5;

text5 = document.getElementById("answer5");

var answers = document.getElementById("answers");


function enter(answer){
	if (answer == 2){
		text.innerHTML = "<h2>" + "Questão 1:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text.innerHTML = "<h2>" + "Questão 1:" + "</h2>" + "<p>" + "Não foi desta vez... " + "</p>" + "<p>" + "A alternativa correta era: " + "<p>51m</p>" +
		"<a href=''>" + "Confira o gabarito aqui" + "</a>";
	}

	question1.className = "question invisible";
	question2.className = "question visible";
	
}

function enter2(answer){
	if (answer == 1){
		text2.innerHTML = "<h2>" + "Questão 2:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text2.innerHTML = "<h2>" + "Questão 2:" + "</h2>" + "<p>" + "Não foi desta vez... " + "</p>" + "<p>" + "A alternativa correta era: " + "</p>" + "<p>30º</p>" +
		"<a href=''>" + "Confira o gabarito aqui" + "</a>";
	}

	question2.className = "question invisible";
	question3.className = "question visible";
	
}

function enter3(answer){
	if (answer == 2){
		text3.innerHTML = "<h2>" + "Questão 3:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text3.innerHTML = "<h2>" + "Questão 3:" + "</h2>" + "<p>" + "Não foi desta vez... " + "</p>" + "<p>" + "A alternativa correta era: " + "</p>" + "<p>2.3Km</p>" +
		"<a href=''>" + "Confira o gabarito aqui" + "</a>";
	}

	question3.className = "question invisible";
	question4.className = "question visible";
	
}

function enter4(answer){
	if (answer == 3){
		text4.innerHTML = "<h2>" + "Questão 4:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text4.innerHTML = "<h2>" + "Questão 4:" + "</h2>" + "<p>" + "Não foi desta vez... " + "</p>" + "<p>" + "A alternativa correta era: " + "</p>" + "<p> 500m </p>" +
		"<a href=''>" + "Confira o gabarito aqui" + "</a>";
	}

	question4.className = "question invisible";
	question5.className = "question visible";
	
}

function enter5(answer){
	if (answer == 3){
		text5.innerHTML = "<h2>" + "Questão 5:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text5.innerHTML = "<h2>" + "Questão 5:" + "</h2>" + "<p>" + "Não foi desta vez... " + "</p>" + "<p>" + "A alternativa correta era:" + "</p>" + "<p>(2 &#8730 5)/5</p>" +
		"<a href=''>" + "Confira o gabarito aqui" + "</a>";
	}

	question5.className = "question invisible";	
	answers.className = "visible";
	
}