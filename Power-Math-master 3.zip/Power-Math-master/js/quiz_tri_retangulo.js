function enter(answer){
	var text;
	text = document.getElementById("inner");

	if (answer == 1){
		text.innerHTML = "Resposta correta!";
	}

	else{
		text.innerHTML = "Resposta incorreta! A resposta certa era a alternativa A!";

	alert(answer);
	}
}