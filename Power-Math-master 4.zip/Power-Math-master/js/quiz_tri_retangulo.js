var question1 = document.getElementById("question1");

var question2 = document.getElementById("question2");

var question3 = document.getElementById("question3");

var question4 = document.getElementById("question4");

var question5 = document.getElementById("question5");

var text;

text = document.getElementById("answer1");

var text2;

text2 = document.getElementById("answer2");

var text3;

text3 = document.getElementById("answer3");

var text4;

text4 = document.getElementById("answer4");

var text5;

text5 = document.getElementById("answer5");

var answers = document.getElementById("answers");


function enter(answer){
	if (answer == 1){
		text.innerHTML = "<h2>" + "Questão 1:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text.innerHTML = "resposta errada";
	}

	question1.className = "question invisible";
	question2.className = "question visible";
	
}

function enter2(answer){
	if (answer == 1){
		text2.innerHTML = "<h2>" + "Questão 2:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text2.innerHTML = "resposta errada";
	}

	question2.className = "question invisible";
	question3.className = "question visible";
	
}

function enter3(answer){
	if (answer == 1){
		text3.innerHTML = "<h2>" + "Questão 3:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text3.innerHTML = "resposta errada";
	}

	question3.className = "question invisible";
	question4.className = "question visible";
	
}

function enter4(answer){
	if (answer == 1){
		text4.innerHTML = "<h2>" + "Questão 4:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text4.innerHTML = "resposta errada";
	}

	question4.className = "question invisible";
	question5.className = "question visible";
	
}

function enter5(answer){
	if (answer == 1){
		text5.innerHTML = "<h2>" + "Questão 5:" + "</h2>" + "<p>" + "Parabéns! " + "</p>" + "<p>" + "Você acertou esta questão!" + "</p>";
	}

	else{
		text5.innerHTML = "resposta errada";
	}

	question5.className = "question invisible";	
	answers.className = "visible";
	
}