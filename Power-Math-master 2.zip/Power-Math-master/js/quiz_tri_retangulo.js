class Question{
	constructor(escolha){
		this.choice1;
		this.choice2;
		this.choice3;
		this.answer1 = 2;
		this.answer2 = 2;
		this.answer3 = 2;
		this.validation1;
		this.validation2;
		this.validation3;
	}

	select1(choice1){
		this.choice1 = choice1;
	}

	validate1(){
		if(this.choice1 == this.answer1){
			this.validation1 = true;
		}

		else{
			this.validation1 = false;
		}
	}

	select2(choice2){
		this.choice2 = choice2;
	}

	validate2(){
		if(this.choice2 == this.answer2){
			this.validation2 = true;
		}

		else{
			this.validation2 = false;
		}
	}

	select3(choice3){
		this.choice3 = choice3;
	}

	validate3(){
		if(this.choice3 == this.answer3){
			this.validation3 = true;
		}

		else{
			this.validation3 = false;
		}
	}
}

var choice1;
var a1;
var r1 = document.getElementById('2');

var choice2;
var a2;
var r2 = document.getElementById('7');

var choice3;
var a3;
var r3 = document.getElementById('12');

var x = new Question();


function select1(escolha1){
	choice1 = escolha1;
	x.select1(choice1);
	a1 = document.getElementById(choice1);
};

function select2(escolha2){
	choice2 = escolha2;
	x.select2(choice2);
	a2 = document.getElementById(choice2);
};

function select3(escolha3){
	choice3 = escolha3;
	x.select3(choice3);
	a3 = document.getElementById(choice3);
};


	




function submit(){

		x.validate1();

		x.validate2();
	
		x.validate3();
			
		
		if(x.validation1 == true){
			a1.style.backgroundColor = '#70db70';
		}
	
		else{
			a1.style.backgroundColor = '#ff4d4d';
			r1.style.backgroundColor = '#70db70';
	
		}
	
	
		if(x.validation2 == true){
			a2.style.backgroundColor = '#70db70';
		}
	
		else{
			a2.style.backgroundColor = '#ff4d4d';
			r2.style.backgroundColor = '#70db70';
	
		}
	
	
		if(x.validation3 == true){
			a3.style.backgroundColor = '#70db70';
		}
	
		else{
			a3.style.backgroundColor = '#ff4d4d';
			r3.style.backgroundColor = '#70db70';
	
		}

}

